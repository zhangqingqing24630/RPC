package flow;

import java.util.concurrent.atomic.AtomicLong;
//new AtomicLong[]{new AtomicLong(0), new AtomicLong(0),
// new AtomicLong(0)}，当前分钟AtomicLong保存的是当前单位时间段内该服务的调用次数
// ，上一分钟显然保存的是上一单位时间段的统计数据，之所以有这个是为了统计需要
// ，既然到了当前的单位时间段，说明上一分钟的访问统计已经结束，
// 即可将上一分钟的该接口的访问量数据打印日志或发送到某个服务端进行统计，
// 因为我们说过，阈值的设置是个不断调优的过程，所以有时候这些统计数据会很有用。
// 在对当前时间段的访问量进行统计的时候，需要将下一分钟的AtomicLong清零

public class ServiceFlowController {

    private AtomicLong[] metricses = new AtomicLong[] { new AtomicLong(0), new AtomicLong(0), new AtomicLong(0) };

    public long incrementAtCurrentMinute() {

        long currentTime = SystemClock.millisClock().now();
        int index = (int) ((currentTime / 30000) % 3);

        AtomicLong atomicLong = metricses[index];
        return atomicLong.incrementAndGet();

    }

    public long getCurrentCallCountAtLastMinute() {

        long currentTime = SystemClock.millisClock().now();
        int index = (int) (((currentTime / 30000)) % 3);
        AtomicLong atomicLong = metricses[index];
        return atomicLong.get();

    }

    public long getLastCallCountAtLastMinute() {

        long currentTime = SystemClock.millisClock().now();
        int index = (int) (((currentTime / 30000) - 1) % 3);
        AtomicLong atomicLong = metricses[index];
        return atomicLong.get();

    }


    public long getNextMinuteCallCount() {

        long currentTime = SystemClock.millisClock().now();
        int index = (int) (((currentTime / 30000) + 1) % 3);
        AtomicLong atomicLong = metricses[index];
        return atomicLong.get();

    }

    public void clearNextMinuteCallCount() {

        long currentTime = SystemClock.millisClock().now();
        int index = (int) (((currentTime / 30000) + 1) % 3);
        AtomicLong atomicLong = metricses[index];
        atomicLong.set(0);
    }

    public AtomicLong[] getMetricses() {
        return metricses;
    }

    public void setMetricses(AtomicLong[] metricses) {
        this.metricses = metricses;
    }

}
