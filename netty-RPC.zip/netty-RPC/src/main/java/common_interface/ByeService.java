package common_interface;

public interface ByeService {
    String bye(String name);
}
