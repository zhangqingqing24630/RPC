package common_interface;


public interface HelloService {
    String hello(HelloObject object);
}
