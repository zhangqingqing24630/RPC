package core.transport;

import lombok.Data;
import lombok.Getter;

import java.io.Serializable;

@Data
@Getter
public class RpcResponse<T>  implements Serializable {
    //服务器调用完这个方法后，需要给客户端返回哪些信息呢
    //响应对应的请求号

    private String requestId;
    //响应状态码
    private Integer statusCode;
    //响应状态补充信息
    private String message;
    //响应数据
    private T data;

    public RpcResponse() {
    }

    public static <T> RpcResponse<T> success(T data, String requestId) {
        RpcResponse<T> response = new RpcResponse<>();
        response.setRequestId(requestId);
        response.setStatusCode(ResponseCode.SUCCESS.getCode());
        response.setData(data);
        return response;
    }

    public static <T> RpcResponse<T> fail(ResponseCode code, String requestId) {
        RpcResponse<T> response = new RpcResponse<>();
        response.setRequestId(requestId);
        response.setStatusCode(code.getCode());
        response.setMessage(code.getMessage());
        return response;
    }
}
