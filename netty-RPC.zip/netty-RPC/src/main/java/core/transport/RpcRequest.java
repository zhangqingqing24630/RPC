package core.transport;

import jdk.nashorn.internal.objects.annotations.Constructor;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;


import java.io.Serializable;
import java.util.Arrays;

@Setter
@Getter

public class RpcRequest implements Serializable {
    //客户端向服务器发送哪些信息，才能唯一确定服务端需要调用的接口的方法?
    //接口名称  接口方法   重载载需要的参数   重载需要的参数类型
    //请求号
    private String requestId;
    private String interfaceName;
    private String methodName;
    private Object[] parameters;
    private Class<?>[] paramTypes;
    //是否是心跳包
    private Boolean heartBeat;
    public RpcRequest() {
    }

    @Override
    public String toString() {
        return "RpcRequest{" +
                "requestId='" + requestId + '\'' +
                ", interfaceName='" + interfaceName + '\'' +
                ", methodName='" + methodName + '\'' +
                ", parameters=" + Arrays.toString(parameters) +
                ", paramTypes=" + Arrays.toString(paramTypes) +
                ", heartBeat=" + heartBeat +
                '}';
    }
}
