package interface_sc;

import core.transport.RpcRequest;
import netty.coder.CommonSerializer;

public interface RpcClient {

    Object sendRequest(RpcRequest rpcRequest);
}
