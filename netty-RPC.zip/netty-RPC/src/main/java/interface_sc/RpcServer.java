package interface_sc;

import netty.coder.CommonSerializer;

public interface RpcServer {
    int DEFAULT_SERIALIZER = CommonSerializer.KRYO_SERIALIZER;
    void start();
    //用于先nacos注册服务
    <T> void publishService(T service, String serviceName);
}
