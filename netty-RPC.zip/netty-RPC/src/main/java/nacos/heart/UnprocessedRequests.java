package nacos.heart;

import core.transport.RpcResponse;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
//但心跳机制暂时不会奏效，因为设置的客户端完成一个调用后立刻关闭连接，接下来会对此进行调整
//我们利用CompletableFuture来异步获取Netty请求的响应结果，
// 将每个请求对应的CompletableFuture实例都保存在一个Map中，key为请求ID，
// value为创建的CompletableFuture实例
public class UnprocessedRequests {
    private static ConcurrentHashMap<String, CompletableFuture<RpcResponse>> unprocessedRequests = new ConcurrentHashMap<>();
    public void put(String requestId, CompletableFuture<RpcResponse> future) {
        unprocessedRequests.put(requestId, future);
    }
    public void remove(String requestId) {
        unprocessedRequests.remove(requestId);
    }
    public void complete(RpcResponse rpcResponse){
        //请求完成了，把请求从未完成的请求中移除
        CompletableFuture<RpcResponse> future = unprocessedRequests.remove(rpcResponse.getRequestId());
        if(null != future){
            //把响应对象放入future中
            future.complete(rpcResponse);
        }else {
            throw new IllegalStateException();
        }
    }
}