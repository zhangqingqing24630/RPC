package nacos.util;

import java.net.InetSocketAddress;

public interface ServiceDiscovery {
    void register(String serviceName, InetSocketAddress inetSocketAddress);
    InetSocketAddress lookupService(String serviceName);
}
