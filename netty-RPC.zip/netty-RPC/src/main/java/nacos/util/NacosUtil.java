package nacos.util;

import com.alibaba.nacos.api.exception.NacosException;
import com.alibaba.nacos.api.naming.NamingFactory;
import com.alibaba.nacos.api.naming.NamingService;
import com.alibaba.nacos.api.naming.pojo.Instance;
import flow.ServiceFlowControllerManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import registry.RpcError;
import registry.RpcException;

import java.net.InetSocketAddress;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class NacosUtil {
    private static final Logger logger = LoggerFactory.getLogger(NacosUtil.class);
    private static final String SERVER_ADDR = "127.0.0.1:8848";
    private static final NamingService namingService;
    private static final Set<String> serviceNames = new HashSet<>();
    private static InetSocketAddress address;
    //连接到Nacos创建命名空间
    public static NamingService getNacosNamingService() {
        try {
            return NamingFactory.createNamingService(SERVER_ADDR);
            }catch (NacosException e) {
            logger.error("连接到Nacos时有错误发生：", e);
            throw new RpcException(RpcError.FAILED_TO_CONNECT_TO_SERVICE_REGISTRY);
            }
        }

    static {
        namingService = getNacosNamingService();
    }

    //description 注册服务到Nacos
    public static void registerService(String serviceName, InetSocketAddress inetSocketAddress) throws NacosException {
        namingService.registerInstance(serviceName, inetSocketAddress.getHostName(), inetSocketAddress.getPort());
        serviceNames.add(serviceName);

        NacosUtil.address=inetSocketAddress;
    }
    //description 获取所有提供该服务的服务端地址
    public static List<Instance> getAllInstance(NamingService namingService, String serviceName) throws NacosException {
        return namingService.getAllInstances(serviceName);
    }
    //如果服务端突然关闭了，并不会自动注销Nacos中对应的服务信息，这样就会导致客户端再次向
    // Nacos请求服务时，可能获取到已经关闭的服务端地址，最终因为连接不到服务器而调用失败。
    // 所以我们要想个办法，在服务端关闭之前自动向Nacos注销服务。其中核心要解决的问题就是，
    // 我们不知道什么时候服务器会关闭，也就不知道这个方法调用的时机，就没有办法手工去调用。
    // 这时，我们就需要钩子。
    //什么是钩子？是在某些事件发生后自动去调用的方法，那么我们只需要把注销服务的方法写到关闭
    // 系统的钩子方法里就行了

    public static void clearRegistry() {
        //所有的服务名称都被存储在serviceNames中
        if(!serviceNames.isEmpty() && address!= null) {
            String host = address.getHostName();
            int port = address.getPort();
            //利用迭代器迭代注销
            Iterator<String> iterator = serviceNames.iterator();
            while (iterator.hasNext()) {
                String serviceName = iterator.next();
                try {
                    //注销服务
                    namingService.deregisterInstance(serviceName, host, port);
                }catch (NacosException e) {
                    logger.error("注销服务{}失败", serviceName, e);
                }
            }
        }
    }

}
