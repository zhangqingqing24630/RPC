package netty.Serializer;

public class SerializeException extends RuntimeException {
    public SerializeException(String msg) {
        super(msg);
    }
}