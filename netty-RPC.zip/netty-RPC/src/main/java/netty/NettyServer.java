package netty;
import interface_sc.RpcServer;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.LineBasedFrameDecoder;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.handler.traffic.GlobalTrafficShapingHandler;
import nacos.hook.ShutdownHook;
import nacos.loadbalance.LoadBalancer;
import nacos.loadbalance.RandomLoadBalancer;
import nacos.loadbalance.RoundRobinLoadBalancer;
import nacos.register.NacosServiceRegistry;
import nacos.register.ServiceRegistry;
import nacos.util.NacosServiceDiscovery;
import nacos.util.ServiceDiscovery;
import netty.Serializer.KryoSerializer;
import netty.coder.CommonDecoder;
import netty.coder.CommonEncoder;
import netty.coder.CommonSerializer;
import netty.test.AbstractRpcServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import registry.RpcError;
import registry.RpcException;
import registry.ServiceProviderImpl;
import registry.ServiceProvider;

import java.net.InetSocketAddress;
import java.util.concurrent.TimeUnit;


public class NettyServer extends AbstractRpcServer {

    private static final Logger logger = LoggerFactory.getLogger(NettyServer.class);
    private final CommonSerializer serializer;
    public NettyServer(String host, int port) {
        this(host,port,DEFAULT_SERIALIZER);
    }
    public NettyServer(String host, int port, Integer serializer) {
        this.host = host;
        this.port = port;
        //serviceRegistry=new NacosServiceRegistry();
        serviceDiscovery=new NacosServiceDiscovery(new RandomLoadBalancer());
        serviceProvider = new ServiceProviderImpl();
        this.serializer = CommonSerializer.getByCode(serializer);
        scanServices();
    }
    @Override
    public void start() {
        //创建两个线程组bossgruop和workergroup
        //bossgroup只处理连接请求，真正和客户端业务处理，交给workergroup
        //两个都是无线循环
        EventLoopGroup bossGroup = new NioEventLoopGroup();
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        try {
            ServerBootstrap serverBootstrap = new ServerBootstrap();
            serverBootstrap.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
                    .handler(new LoggingHandler(LogLevel.INFO))
                    .option(ChannelOption.SO_BACKLOG, 256)
                    //.option(ChannelOption.SO_KEEPALIVE, true)
            //设置这样做好的好处就是禁用nagle算法
//            但这不是重点, 关键是这个算法受TCP延迟确认影响, 会导致相继两次向连接发送请求包,
//            读数据时会有一个最多达500毫秒的延时.
//            TCP/IP协议中，无论发送多少数据，总是要在数据前面加上协议头，
//            同时，对方接收到数据，也需要发送ACK表示确认。为了尽可能的利用网络带宽
//            Nagle算法就是为了尽可能发送大块数据，避免网络中充斥着许多小数据块

                    .childOption(ChannelOption.TCP_NODELAY, true)
                    .childHandler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        protected void initChannel(SocketChannel ch) throws Exception {
                            ChannelPipeline pipeline = ch.pipeline();
                            // 流量整形
                            //pipeline.addLast(new GlobalTrafficShapingHandler(ch.eventLoop().parent(), 10, 10));
                            pipeline.addLast(new IdleStateHandler(40, 0, 0, TimeUnit.SECONDS));
                            pipeline.addLast(new CommonEncoder(serializer));
                            pipeline.addLast(new CommonDecoder());
                            pipeline.addLast(new NettyServerHandler());
                        }
                    });
            //绑定端口号，生成了一个ChannelFuture对象
            //启动服务器，并绑定端口
            ChannelFuture future = serverBootstrap.bind(host,port).sync();
            ShutdownHook.getShutdownHook().addClearAllHook();
            //对关闭通道进行监听
            future.channel().closeFuture().sync();

        } catch (InterruptedException e) {
            logger.error("启动服务器时有错误发生: ", e);
        } finally {
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }
    }
}
