package netty.test;

import annotation.RPCService;
import annotation.Service;
import common_interface.ByeService;

@Service
public class ByeServiceImpl implements ByeService {

    @Override
    @RPCService(responsibilityName="xiaoy",serviceName="LAOPOPO.TEST.SAYHELLO",maxCallCountInMinute = 15
    ,degradeServicePath="netty.test.ByeServiceMock")
    public String bye(String name) {
        return "正常发送, " + name;
    }
    public String fail(String name) {
        return "服务降级"+name;
    }

}
