package netty.test;

import annotation.ServiceScan;
import interface_sc.RpcServer;
import netty.NettyServer;

@ServiceScan
public class NettyTestServer {
    public static void main(String[] args) {
        NettyServer server = new NettyServer("127.0.0.1", 4, RpcServer.DEFAULT_SERIALIZER);
        server.start();
    }

}

