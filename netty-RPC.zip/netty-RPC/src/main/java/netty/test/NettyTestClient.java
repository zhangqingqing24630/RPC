package netty.test;

import client.RpcClientProxy;
import common_interface.ByeService;
import flow.ServiceFlowControllerManager;
import nacos.hook.ThreadPoolFactory;
import netty.NettyClient;
import sun.nio.ch.ThreadPool;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class NettyTestClient {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        NettyClient client = new NettyClient();
        RpcClientProxy rpcClientProxy = new RpcClientProxy(client);

//        HelloService helloService = rpcClientProxy.getProxy(HelloService.class);
//        HelloObject object = new HelloObject(12, "This is a message");
//        String res = helloService.hello(object);
//        System.out.println(res);

        ServiceFlowControllerManager serviceFlowControllerManager=new ServiceFlowControllerManager();
        serviceFlowControllerManager.setServiceLimitVal("ss",1L);


        //for(int index = 1;index < 40;index++) {
            ByeService byeService = rpcClientProxy.getProxy(ByeService.class);
            byeService.bye("byebye");
            //System.out.println("当前调用的次数是：" + index);
            //byeService.bye(String.valueOf(index));
        //}
    }
}

