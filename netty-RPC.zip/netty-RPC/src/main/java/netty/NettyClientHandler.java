package netty;
//

import core.transport.RpcRequest;
import core.transport.RpcResponse;
import flow.ServiceFlowControllerManager;
import io.netty.channel.*;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import nacos.heart.UnprocessedRequests;
import nacos.hook.SingletonFactory;
import nacos.hook.ThreadPoolFactory;
import nacos.util.NacosUtil;
import netty.coder.CommonSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;
import java.util.Deque;
import java.util.LinkedList;
import java.util.concurrent.*;

public class NettyClientHandler extends SimpleChannelInboundHandler<RpcResponse> {

    private static final Logger logger = LoggerFactory.getLogger(NettyClientHandler.class);
    private final UnprocessedRequests unprocessedRequests;
    public NettyClientHandler() {
        this.unprocessedRequests = SingletonFactory.getInstance(UnprocessedRequests.class);
    }
    //public static final ServiceFlowControllerManager serviceFlowControllerManager=new ServiceFlowControllerManager("ll",10L);
//    public static class MetricsScanner implements Runnable {
//
//        @Override
//        public void run() {
//            for (;;) {
//                logger.info("统计中");
//                try {
//                    Thread.sleep(8000);
//                    logger.info("上一秒调用的次数是[{}]",serviceFlowControllerManager.getLastMinuteCallCount("ll"));
//                    logger.info("当前秒调用的次数是[{}]",serviceFlowControllerManager.getCurrentCallCount("ll"));
//                    logger.info("下以秒调用的次数是[{}]",serviceFlowControllerManager.getNextMinuteCallCount("ll"));
//
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//    }

    //private static final ScheduledExecutorService scheduledExecutorService= Executors.newSingleThreadScheduledExecutor(ThreadPoolFactory.createThreadFactory("provider-timer",null));;
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, RpcResponse msg) throws Exception {
//        Thread t = new Thread(new MetricsScanner());
//        t.setDaemon(true);
//        t.start();
//        //serviceFlowControllerManager.setServiceLimitVal("ll",20L);
//        //我们还需要有个定时任务，定时清理下一个槽位的已经统计的值
//        scheduledExecutorService.scheduleAtFixedRate(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    System.out.println("清理下一个时间的槽位");
//                    serviceFlowControllerManager.clearAllServiceNextMinuteCallCount();
//                } catch (Exception e) {
//                    logger.warn("schedule publish failed [{}]", e.getMessage());
//                }
//            }
//            //我们每隔45秒清理一下下一个时间段的槽位
//        }, 3, 15, TimeUnit.SECONDS);
//        Deque<RpcResponse> queue=new LinkedList<>();
//        if(serviceFlowControllerManager.isAllow("ll")) {
//            if (!queue.isEmpty()) {
//                queue.addLast(msg);
//                logger.info(String.format("客户端接收到消息: %s", queue.removeFirst()));
//                serviceFlowControllerManager.incrementCallCount("ll");
//            } else {
//                Thread.sleep(1000l);
//                logger.info(String.format("客户端接收到消息: %s", msg));
//                serviceFlowControllerManager.incrementCallCount("ll");
//                unprocessedRequests.complete(msg);
//            }
//        }else {
//                System.out.println("服务减速===");
//                Thread.sleep(400l);
//                queue.addLast(msg);
//                unprocessedRequests.complete(msg);
//            }
//        try {
//            logger.info(String.format("客户端接收到消息: %s", msg));
//            unprocessedRequests.complete(msg);
//        } finally {
//            ReferenceCountUtil.release(msg);
//        }
    }
    //首先是客户端的心跳检测实现,如果5秒内write()方法未被调用则触发一次userEventTrigger()方法
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if(evt instanceof IdleStateEvent){
            IdleState state = ((IdleStateEvent) evt).state();
            if(state == IdleState.WRITER_IDLE){
                logger.info("发送心跳包[{}]", ctx.channel().remoteAddress());
                Channel channel = ChannelProvider.get((InetSocketAddress) ctx.channel().remoteAddress(), CommonSerializer.getByCode(CommonSerializer.DEFAULT_SERIALIZER));
                RpcRequest rpcRequest = new RpcRequest();
                rpcRequest.setHeartBeat(true);
                //设置一个Listener监测服务端是否接收到心跳包，如果接收到就代表对方在线，不用关闭Channel
                channel.writeAndFlush(rpcRequest).addListener(ChannelFutureListener.CLOSE_ON_FAILURE);
            }
        }else {
            super.userEventTriggered(ctx, evt);
        }
    }




    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        logger.error("过程调用时有错误发生:");
        cause.printStackTrace();
        ctx.close();
    }

}

