package client;


import core.transport.RpcRequest;
import core.transport.RpcResponse;
import interface_sc.RpcClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

//客户端方面，由于在客户端这一侧我们并没有接口的具体实现类，
//就没有办法直接生成实例对象。
//这时，我们可以通过动态代理的方式生成实例，
//并且调用方法时生成需要的RpcRequest对象并且发送给服务端。
public class RpcClientProxy implements InvocationHandler {
    private static final Logger logger = LoggerFactory.getLogger(RpcClientProxy.class);
    private final RpcClient rpcClient;
    public RpcClientProxy(RpcClient rpcClient) {
        this.rpcClient = rpcClient;
    }

    @SuppressWarnings("unchecked")
    //loader: 用哪个类加载器去加载代理对象
//interfaces:动态代理类需要实现的接口，方法
//h:动态代理方法在执行时，会调用h里面的invoke方法去执行，继承InvocationHandler
    public <T> T getProxy(Class<T> clazz) {
        return (T)Proxy.newProxyInstance(clazz.getClassLoader()
        ,new Class<?>[]{clazz},
                this);
    }
    //根据接口产生响应的服务请求
    //接口需要实现invoke()方法，来指明代理对象的方法被调用时的动作

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        logger.info("调用方法: {}#{}", method.getDeclaringClass().getName(), method.getName());
        RpcRequest rpcRequest=new RpcRequest();
        rpcRequest.setInterfaceName(method.getDeclaringClass().getName());
        //rpcRequest.setMethodName(method.getName());
        rpcRequest.setMethodName("fail");
        rpcRequest.setParameters(args);
        rpcRequest.setParamTypes(method.getParameterTypes());
        rpcRequest.setHeartBeat(false);
        rpcRequest.setRequestId(UUID.randomUUID().toString());
        CompletableFuture completableFuture=(CompletableFuture) rpcClient.sendRequest(rpcRequest);
        RpcResponse rpcResponse=(RpcResponse) completableFuture.get();
        return rpcResponse.getData();
    }
}
