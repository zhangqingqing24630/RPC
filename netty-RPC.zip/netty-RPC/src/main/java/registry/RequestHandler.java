package registry;

import core.transport.ResponseCode;
import core.transport.RpcRequest;
import core.transport.RpcResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

//RequestHandlerThread 只是一个线程，从ServiceRegistry 获取到提供服务的对象后，
//就会把 RpcRequest 和服务对象直接交给 RequestHandler 去处理，
//反射等过程被放到了 RequestHandler 里
public class RequestHandler {
    private static final Logger logger = LoggerFactory.getLogger(RequestHandler.class);
    private static final ServiceProvider serviceProvider;
    static {
        serviceProvider=new ServiceProviderImpl();
    }
    public Object handle(RpcRequest rpcRequest) {
        Object result = null;
        try {
            Object service=serviceProvider.getService(rpcRequest.getInterfaceName());
            result = invokeTargetMethod(rpcRequest, service);
            logger.info("服务:{} 成功调用方法:{}", rpcRequest.getInterfaceName(), rpcRequest.getMethodName());
        } catch (IllegalAccessException | InvocationTargetException e) {
            logger.error("调用或发送时有错误发生：", e);
        } return result;
    }
    private Object invokeTargetMethod(RpcRequest rpcRequest, Object service) throws IllegalAccessException, InvocationTargetException, InvocationTargetException {
        //反射
        Method method;
        try {
            //获取要调用的方法
            method = service.getClass().getMethod(rpcRequest.getMethodName(), rpcRequest.getParamTypes());
        } catch (NoSuchMethodException e) {
            return RpcResponse.fail(ResponseCode.METHOD_NOT_FOUND, rpcRequest.getRequestId());
        }
        //反射，根据客户端要调用的方法method和参数类型来执行
        return method.invoke(service, rpcRequest.getParameters());
    }
}
