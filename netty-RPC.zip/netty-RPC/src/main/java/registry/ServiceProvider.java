package registry;
//我们需要一个容器，这个容器很简单，就是保存一些本地服务的信息，
//并且在获得一个服务名字的时候能够返回这个服务的信息。创建一个 ServiceRegistry 接口：
public interface ServiceProvider {
    <T> void addServiceProvider(T service, String serviceName);//注册服务信息
    Object getService(String serviceName);//获取服务信息
}
